from django.urls import path
from company_app import views
from django.conf import settings
from django.conf.urls.static import static

app_name = 'company_app'

urlpatterns = [
    path('', views.home, name='home'),
    path('comment/', views.comment_form, name='comment_form'),
    path('info/', views.info_list, name='info'),
    path('jobs_list/', views.jobs_list, name='jobs_list'),
    path('read_jobs/<id>/', views.read_jobs, name='jobs_view'),    
    path('official/',views.official, name='official'),
    path('register/', views.register, name='register'),
    path('login/',views.login_page,name='login'),
    path('logout/',views.logout_page, name='exit'),
    path('read_info/<id>/',views.read_info,name='read_info')
    
    
    # Add other URL patterns here
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
   
# Serve static files during development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# Serve media files during development
# urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
