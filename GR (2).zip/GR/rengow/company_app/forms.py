from django import forms
from .models import Info ,job,comments
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class InfoForm(forms.ModelForm):
    class Meta:
        model = Info
        fields = ['Company','Picture','ShortDesc','BriefDesc','Start_date','active','PageLink','location','post_date']
        # exclude = ['Time']
        
class RegistrationForm(UserCreationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter User Name'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter User Email'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Create password'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm password'}))
    first_name = forms.IntegerField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter phone_number'}))
    last_name =  forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'example: student / worker'}))

#   laste-name is the status
# first_name is the phone_number
        
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')



class commentForm(forms.ModelForm):
    comment = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'comments'}))  
    
   
    class Meta:
        model = comments
        fields ='__all__'
        # fields = ['comment','User']


class jobsForm(forms.ModelForm):
    class Meta:
        model = job
        fields = ['Picture','Picture_l','Picture_ll','Picture_lll','Picture_lv','job_name','location','ShortDesc','BriefDesc','post_date','PageLink']
        # exclude = ['Time']
        