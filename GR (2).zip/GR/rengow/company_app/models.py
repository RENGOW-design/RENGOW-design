from django.db import models
from django.contrib.auth.models import User
# from django.utils.translation import gettext_lazy as _
# from django.utils.translation import ugettext_lazy as _
# from django.utils.translation import gettext_lazy as _
# Create your models here.

class Info(models.Model):
    id = models.AutoField(primary_key=True)
    Picture = models.ImageField()
    Company = models.CharField(max_length=60)
    location = models.CharField(max_length=60)
    ShortDesc = models.TextField(max_length=150)
    BriefDesc = models.TextField(max_length=3000)
    post_date = models.DateField()
    Start_date = models.DateField()
    active = models.CharField(max_length=40)
    PageLink = models.CharField(max_length=80)

    def __str__(self):
        return self.Company

class job(models.Model):
    id = models.AutoField(primary_key=True)
    Picture = models.ImageField()
    job_name = models.CharField(max_length=60)
    Picture_l = models.ImageField()
    Picture_ll = models.ImageField()
    Picture_lll = models.ImageField()
    Picture_lv = models.ImageField()
    location = models.CharField(max_length=60)
    ShortDesc = models.TextField(max_length=150)
    BriefDesc = models.TextField(max_length=3000)
    post_date = models.DateField()
    PageLink = models.CharField(max_length=80)

    def __str__(self):
        return self.job_name



class comments(models.Model):
    comment = models.TextField(max_length=200)
    User = models.ForeignKey(User, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.comment