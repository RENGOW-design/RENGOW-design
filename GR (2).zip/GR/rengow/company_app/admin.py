from django.contrib import admin

# Register your models here.
from .models import Info ,job,comments

admin.site.register(Info)
admin.site.register(job)
admin.site.register(comments)


