from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout,authenticate
from django.contrib import messages
from company_app.models import *
from company_app.forms import *
from django.http import HttpResponse
from django.contrib.auth.models import User 
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
# # from django.utils import generate_otp, send_otp, authenticate_phone_number
# from MyApp.utils import generate_otp, send_otp, authenticate_phone_number

# Create your views here.


def comment_form(request):
    form = commentForm()
    if request.method=='POST':
        form=commentForm(request.POST)
        if form.is_valid():
          form.save()
          return redirect('/')
    else:
        form = commentForm()
    return render(request, 'main/comments.html',{'form':form})

# def  dssfffs(request):
#     if request.method == 'POST':
#         form = commentForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('/')
#           # return redirect('success')  # Redirect to a success page after form submission
#     else:
#         form = commentForm()
#     return render(request, 'comments.html', {'form': form})

# def success(request):
#     return render(request, 'success.html')


def home(request):
    pass
    return render(request,'main/home.html')

def error404(request,exception):
    pass
    return render(request,'main/404.html')

    
def register(request):
    form = RegistrationForm()
    if request.method=='POST':
        form=RegistrationForm(request.POST)
        if form.is_valid():
          form.save()
          return redirect('/login/')
    return render(request, 'main/register.html',{'form':form})

def login_page(request):
    if request.user.is_authenticated:
        return redirect("/")
    else:        
        if request.method == 'POST':
            name = request.POST.get('username')
            password = request.POST.get('password')
            try:
                user = authenticate(request, username=name, password=password)
                if user is not None:
                    login(request, user)
                    messages.success(request, "Logged in successfully")
                    return redirect("/")  # Replace 'home' with the URL name of your home page
                else:
                    messages.error(request, "Invalid username or password")
                    return redirect("/login/")
            except User.DoesNotExist:
                  return redirect("/register/")
        return render(request,'main/login.html')

    # return render(request,'MyApp/login.html')


def logout_page(request):
    if request.user.is_authenticated:
      logout(request)
      messages.success(request,"Logged Out Successfully")
    return redirect("/")


@login_required
def jobs_list(request):
    info = job.objects.all()
    return render(request, 'main/jobs_list.html', {'jobs': info})

@login_required
def read_jobs(request,id):
    jobs = get_object_or_404(job, id=id)
    return render(request, 'main/view_jobs.html', {'info': jobs})



@login_required
def info_list(request):
    infos = Info.objects.all()
    return render(request, 'main/info_list.html', {'infos': infos})

@login_required
def read_info(request,id):
    infos = get_object_or_404(Info, id=id)
    return render(request, 'main/view_info.html', {'info': infos})


@login_required
def official(request):
    pass
    return render(request,'main/official.html')